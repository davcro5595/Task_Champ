/*
Cassie Chappell
David Crouch
Joshua Daniels
CIS 480
ToDoList App
 */
package net.androidbootcamp.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {
    EditText newUsername, regemail, passwordRegister, passwordReenter; //textboxes for the registration page//
    Button createAccount; //create account button for the registration page//
    DatabaseHelper DB;

    Button loginR; //called LoginR so I know the login button is on the registration page. Is not the actual login button//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        //establishing all text boxes and buttons for registration//
        newUsername = (EditText) findViewById(R.id.newUsername);
        regemail = (EditText) findViewById(R.id.regemail);
        passwordRegister = (EditText) findViewById(R.id.passwordRegister);
        passwordReenter = (EditText) findViewById(R.id.passwordReenter);
        createAccount = (Button) findViewById(R.id.createAccount);
        DB = new DatabaseHelper( this);

        //Create account button and events//
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            //setting up all the variables to make a new account while also making it work with the database
            public void onClick (View view) {
                String user = newUsername.getText().toString();
                String email = regemail.getText().toString();
                String pass = passwordRegister.getText().toString();
                String repass = passwordReenter.getText().toString();

                //Setting requirements for registration, this one means no fields can be blank//
                if(user.equals("") ||email.equals ("")||pass.equals("")||repass.equals(""))
                    Toast.makeText(Registration.this, "Fields cannot be blank", Toast.LENGTH_SHORT).show();
                else {

                    //ensures that the password and password reenter are equal//
                    //Will also tell if the account has been created successfully//
                    if(pass.equals(repass)) {
                        Boolean checkuser = DB.checkUsername(user);
                        if (checkuser == false) {
                            Boolean insert = DB.insertData(user, pass);
                            if (insert == true) {
                                Toast.makeText(Registration.this, "New user created successfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Registration.this, Login.class));
                            } else {
                                Toast.makeText(Registration.this, "Account creation failed, try again.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Registration.this, "Username already in use, please try a different one.", Toast.LENGTH_SHORT).show();
                        }
                    } else{
                        Toast.makeText(Registration.this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        //opens login page when the login button is clicked//
        loginR = (Button) findViewById(R.id.loginR);
        loginR.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Registration.this, Login.class));
            }
        });
    }
}