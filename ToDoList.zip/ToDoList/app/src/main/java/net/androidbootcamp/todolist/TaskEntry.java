/*
Cassie Chappell
David Crouch
Joshua Daniels
CIS 480
ToDoList App
 */

package net.androidbootcamp.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class TaskEntry extends AppCompatActivity {

    //create an ArrayList to store the tasks that the user types
    ArrayList<String> tasks = new ArrayList<String>();
    //create just variables since I do not know how to make an Arraylist work

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_entry);

        //initiate the EditText controls
        final EditText taskText1 = (EditText) findViewById(R.id.InputTaskText1);
        final EditText taskText2 = (EditText) findViewById(R.id.InputTaskText2);
        final EditText taskText3 = (EditText) findViewById(R.id.InputTaskText3);
        final EditText taskText4 = (EditText) findViewById(R.id.InputTaskText4);
        final EditText taskText5 = (EditText) findViewById(R.id.InputTaskText5);

        //initiate the buttons
        Button prioritizeBtn = (Button) findViewById(R.id.PrioritizeBtn);
        Button submitBtn = (Button) findViewById(R.id.SubmitBtn);

        //Create a SharedPreferences object
        final SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        //set a listener for when the PrioritizeBtn gets clicked
        prioritizeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Read and store the user input into the SharedPreferences
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("key1", taskText1.getText().toString());
                editor.putString("key2", taskText2.getText().toString());
                editor.putString("key3", taskText3.getText().toString());
                editor.putString("key4", taskText4.getText().toString());
                editor.putString("key5", taskText5.getText().toString());
                //save the changes
                editor.apply(); //?Do we want to use commit or apply?

                //launch the Comparison Prioritization activity
                startActivity(new Intent(TaskEntry.this, ComparisonPrioritization.class));
            }// end onClick method
        });//end setOnClickListener

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*//read the user input into the ArrayList
                tasks.set(0, (task1.getText().toString()));
                tasks.set(1, (task2.getText().toString()));
                tasks.set(2, (task3.getText().toString()));
                tasks.set(3, (task4.getText().toString()));
                tasks.set(4, (task5.getText().toString()));

                //Store the ArrayList in the shared preferences
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("key1", tasks.get(0));
                editor.putString("key2", tasks.get(1));
                editor.putString("key3", tasks.get(2));
                editor.putString("key4", tasks.get(3));
                editor.putString("key5", tasks.get(4));
                //save the changes
                editor.apply();
                */

                //Display a Toast message indicating that the tasks have been saved in their current order
                Toast.makeText( TaskEntry.this, "The tasks have been saved under a new project",
                        Toast.LENGTH_LONG).show();
            }// end onClick method
        });//end setOnClickListener

    }//end onCreate method
}//end class TaskEntry