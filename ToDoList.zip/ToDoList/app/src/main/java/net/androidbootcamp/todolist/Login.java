/*
Cassie Chappell
David Crouch
Joshua Daniels
CIS 480
ToDoList App
 */
package net.androidbootcamp.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    //EditText usernameLogin, passwordLogin; //textboxes for the sign in page//
    //Button login; //creating the login button;
    //Button registration; //create the login button
    //DatabaseHelper DB; //Create a DatabaseHelper

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText usernameLogin = (EditText) this.findViewById(R.id.usernameLogin);
        final EditText passwordLogin = (EditText) this.findViewById(R.id.passwordLogin);
        final Button loginBtn = (Button) findViewById(R.id.loginBtn);
        final Button registrationBtn = (Button) this.findViewById(R.id.registrationBtn);
        final DatabaseHelper DB = new DatabaseHelper(this);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = usernameLogin.getText().toString();
                String pass = passwordLogin.getText().toString();

                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(Login.this, "Fields cannot be blank", Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean checkUserPass = DB.checkUsernamePassword(user, pass); //check if the username and password are legitimate
                    if (checkUserPass) {
                        Toast.makeText(Login.this, "Login successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Login.this, TaskEntry.class));
                    }
                    else {
                        Toast.makeText(Login.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                    } //end else for invalid username and password
                } //end else that checks if both fields are filled
            } //end OnClick
        });  //end OnClickListener



        //opens registrationBtn page when registrationBtn button is clicked//
        registrationBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Login.this, Registration.class));
            }  //end onClick
        }); //end OnClickListener
    } //end onCreate method
} //end Login class