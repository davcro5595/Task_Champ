/*
Cassie Chappell
Joshua Daniels
David Crouch
CIS 480
ToDoList App
 */
package net.androidbootcamp.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Arrays;

public class ComparisonPrioritization extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparison_prioritization);

        //Use the SharedPreferences to get the task descriptions
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        //store the size of the ArrayList
        int size = sharedPref.getAll().size();
        final Priority[] task = new Priority[sharedPref.getAll().size()];

        task[0] = new Priority(sharedPref.getString("key1", "task placeholder"), 0);
        task[1] = new Priority(sharedPref.getString("key2", "task placeholder"), 0);
        task[2] = new Priority(sharedPref.getString("key3", "task placeholder"), 0);
        task[3] = new Priority(sharedPref.getString("key4", "task placeholder"), 0);
        task[4] = new Priority(sharedPref.getString("key5", "task placeholder"), 0);
        Search(size, task);
    }//end onCreate method

        public void Search (int s, final Priority [] task) {
            //instantiate necessary objects
            final Button task1Btn = (Button) findViewById(R.id.Task1Btn);
            final Button task2Btn = (Button) findViewById(R.id.Task2Btn);
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

            //for loops that perform the search
            for (int i = 0; i <= s-1 ; i++) {            // search array
            for (int j = 0; j <= s-1; j++) {            // search array
                if (task[i].getPriority() == task[j].getPriority()) { //check if both priorities are the same
                    if (task[i].getTask() != task[j].getTask()) {  // check if both task are different
                        final String task1 = task[i].getTask();
                        final int finalI = i; // store iteration in a final variable
                        task1Btn.setText((CharSequence) task[i].getTask()); // change text to task
                        final String task2 = task[j].getTask(); // backup string variable for testing
                        final int finalJ = j; // store iteration in a final variable
                        final int finals = s;
                        task2Btn.setText((CharSequence) task[j].getTask());// change text to task
                        task1Btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                task[finalI].updatePriority();
                                Search(finals, task); //call search again
                            }// end onClick method
                        });//end setOnClickListener
                        task2Btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                task[finalJ].updatePriority();

                                Search(finals, task); // call search again
                            }// end onClick method;
                        });//end setOnClickListener
                    } //end if statement checking if the tasks are different
                } //end if statement checking whether the priorities are the same
            } //end inner for loop
        }// end outer for loop

        for (int i = 0; i <= s-1 ; i++) { // search
            for (int j = 0; j <= s-1; j++) { //search
                if (task[i].getPriority()>=s-1 ||task[j].getPriority()>=s-1) // i don't know if i need this but it works
                {    //create array to store new string order
                    String[] array = new String[s];
                    // store new order by priority
                    for(int y=0;y<=s-1;y++) {
                        if (task[y].getPriority() == 4) {
                            array[0] = task[y].getTask();
                        }
                        if (task[y].getPriority() == 3) {
                            array[1] = task[y].getTask();
                        }
                        if (task[y].getPriority() == 2) {
                            array[2] = task[y].getTask();
                        }
                        if (task[y].getPriority() == 1) {
                            array[3] = task[y].getTask();
                        }
                        if(task[y].getPriority() == 0){
                            array[4] = task[y].getTask();
                        }
                    }
                    //store new array in shared preferences
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("key1", array[0]);
                    editor.putString("key2", array[1]);
                    editor.putString("key3", array[2]);
                    editor.putString("key4", array[3]);
                    editor.putString("key5", array[4]);
                    editor.apply(); // apply changes
                    change(); // run method to change screen
                }
            }}
    }// end Search method
    private  void change() {
        startActivity(new Intent(ComparisonPrioritization.this, PrioritizationResults.class));
    } //end change() method
} //end ComparisonPrioritization class
