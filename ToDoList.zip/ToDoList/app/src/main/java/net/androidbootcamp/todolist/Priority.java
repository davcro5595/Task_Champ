package net.androidbootcamp.todolist;

//This class is used for keeping track of a task and the priority value that it has
public class Priority {

    //declare variables
    public String task;
    public int priority;
    //constructor methods
    public Priority(String task, int priority)
    {
        this.task= task;
        this.priority = priority;
    }

    //set methods
    public void setTask (String t)
    {this.task = t;}

    //get methods
    public  String getTask()
    {
        return task;
    }

    public int getPriority()
    {
        return priority;
    }

    public int updatePriority()
    {
        priority++;
        return priority;
    }
}