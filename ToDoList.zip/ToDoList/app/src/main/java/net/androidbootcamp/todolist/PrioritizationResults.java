/*
Cassie Chappell
Joshua Daniels
David Crouch
CIS 480
ToDoList App
 */

package net.androidbootcamp.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PrioritizationResults extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prioritization_results);

        //Display the text of the tasks in their proper order.

        //Instantiate objects from the layout
        TextView resultTask1TextView = (TextView) findViewById(R.id.resultTask1TextView);
        TextView resultTask2TextView = (TextView) findViewById(R.id.resultTask2TextView);
        TextView resultTask3TextView = (TextView) findViewById(R.id.resultTask3TextView);
        TextView resultTask4TextView = (TextView) findViewById(R.id.resultTask4TextView);
        TextView resultTask5TextView = (TextView) findViewById(R.id.resultTask5TextView);
        Button SaveListBtn = (Button) findViewById(R.id.SaveListBtn);
        Button CreateNewListBtn = (Button) findViewById(R.id.CreateNewListBtn);

        //retrieve user entries from the SharedPreferences
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        //set TextViews to display the tasks entered
        resultTask1TextView.setText(sharedPref.getString("key1", "#1 Placeholder"));
        resultTask2TextView.setText(sharedPref.getString("key2", "#2 Placeholder"));
        resultTask3TextView.setText(sharedPref.getString("key3", "#3 Placeholder"));
        resultTask4TextView.setText(sharedPref.getString("key4", "#4 Placeholder"));
        resultTask5TextView.setText(sharedPref.getString("key5", "#5 Placeholder"));


        SaveListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Display a Toast message indicating that the tasks have been saved in their current order
                Toast.makeText(PrioritizationResults.this, "The tasks have been saved under a new project",
                        Toast.LENGTH_LONG).show();
            }
        });// SaveListBtn.setOnClickListener
        CreateNewListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PrioritizationResults.this, TaskEntry.class));
            }//end onClick method

        }); //end CreateNewListBtn.setOnClickListener
    }
}